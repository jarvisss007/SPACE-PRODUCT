Golapada offline

Unzip this folder and open index.html in any web browser.
Everything is calculated on your own computer. Fonts, the live Earth photographs
and the satellite-tracking library need the internet; satellite positions are from
the day this copy was made, so download a fresh one every week or two.
